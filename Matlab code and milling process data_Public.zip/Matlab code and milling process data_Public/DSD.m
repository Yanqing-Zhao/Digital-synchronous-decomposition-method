function [PNB_component,TV_component] = DSD(x,M,N)

% x: Period-N bifurcation signal (synchronous signal) 
% M: Number of data samples collected in the fundamental period
% N: Number of data samples in one stroboscopic sampled data series
% PNB_component: Period-N bifurcation component
% PNB_component: Period-N bifurcation component
% TV_component: Typical vibration component

% Yanqing ZHAO
% 2023-01-06


Dis = zeros(M,N);% 
M_Dis = zeros(M,N);

B_component = zeros(M,N);% Decomposed bifucation component


for i = 1:M

 Dis(i,:) = x( i: M : 0+(N-1)*M+i );
 for j = 1:N
 M_Dis(i,j) = 1/N*sum(Dis(i,1:N));%+Dis(i,2)+Dis(i,3)+Dis(i,4));
 end
 
 B_component(i,:) = Dis(i,:) - M_Dis(i,:); % Decomposed period-4 bifucation component

end

PNB_component = reshape(B_component,1,M*N);
TV_component = x - PNB_component;

end