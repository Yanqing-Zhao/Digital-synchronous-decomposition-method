clc;
clear;
close all;

%% Stable I
% load('Stable I.mat')
% M = 400;
% N = 2;
%% Stable II
% load('Stable II.mat')
% M = 400;
% N = 2;
%% Stable III
% load('Stable III.mat')
% M = 400;
% N = 2;
% n = length(x(:));
% Signal = x(n-M*N+1:end);
%% Stable IV
% load('Stable IV.mat')
% M = 400;
% N = 2;
%% Period-2 bifurcation I 
% load('Period-2 bifurcation I.mat')
% M = 400;
% N = 2;
% n = length(x(:));
% Signal = x(n-M*N+1:end);
%% Period-2 bifurcation II 
% load('Period-2 bifurcation II.mat')
% M = 400;
% N = 2;
%% Period-2 bifurcation III 
% load('Period-2 bifurcation III.mat')
% M = 400;
% N = 2;

%% Period-3 bifurcation I
% load('Period-3 bifurcation I.mat')
% M = 400;
% N = 3;
%% Period-3 bifurcation II
% load('Period-3 bifurcation II.mat')
% M = 400;
% N = 3;
%% Period-3 bifurcation III
% load('Period-3 bifurcation III.mat')
% M = 400;
% N = 3;

%% Period-2 bifurcation I (cutting tool) 
load('Period-2 bifurcation I of the cutting tool.mat')
M = 400;
N = 14; 


[PNB_component,TV_component] = DSD(Signal,M,N);

figure(1)
plot(1/M:1/M:(M*N)/M,Signal,'b')
xlabel('Revolutions')
ylabel('Displacement (��m) ');

figure(2)
plot(1/M:1/M:(M*N)/M,PNB_component,'b')
xlabel('Revolutions')
ylabel('Displacement (��m) ');

figure(3)
plot(1/M:1/M:(M*N)/M,TV_component,'b')
xlabel('Revolutions')
ylabel('Displacement (��m) ');

mean(abs(PNB_component));% Period-N bifurcation size
